# StudyFlow CZ v0.3

Tato verze je záměrně **jeden samostatný HTML soubor**.

## Jak ji otevřít
Na tabletu otevři `StudyFlow.html` v prohlížeči. CSS a JavaScript jsou uvnitř souboru, takže není potřeba řešit načítání `style.css` nebo `app.js`.

## Co obsahuje
- české rozhraní
- přehled
- knihovnu
- kartičky
- kvíz
- pokrok
- lokální ukládání
- responzivní tabletové rozhraní

Poznámka: tato verze ještě neobsahuje skutečné AI zpracování PDF. To bude další vývojový krok.
